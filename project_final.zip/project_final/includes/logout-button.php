<?php

    if(isset($_SESSION["email"])) {
    /*your logout button*/
?>
    <a class="" style="width = 10px;"href="logout.php">
    <img src="../images/design/signout.png" alt="" height="20px" width="20px">
    Log Out
    </a>

<?php

    } else {
    /*your login button*/
    
    }

?>
