
  <br>
  <footer>  Book and Comic Inc. &copy; <?php echo date("Y"); // Updates year for Copyright?> </footer>
</div>
</div>
</body>
